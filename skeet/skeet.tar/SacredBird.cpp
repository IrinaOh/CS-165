#include "SacredBird.h"

void SacredBird::draw()
{
   if (_alive)
   drawSacredBird(_v.getPoint(), 15);   
}


#include "lander.h"


void Lander::draw() 
{
	drawLander(coordinate);
}